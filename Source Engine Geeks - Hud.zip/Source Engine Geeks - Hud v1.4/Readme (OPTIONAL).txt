Steps:
1. Extract the files to: [Steam_Dir]/Steamapps/Common/Half-Life 2 Deathmatch/Hl2MP/Custom ...
2. Then remove the old folder outline_hud / hud_outline if its still there...
Then start up your game ^^...

Information:
====================================
=    This hud was created by...    =
=           NavyCommander          =
=                To                =
=              Request             =
=              -------             =
=              Suggest             =
=               Email:             =
=       NicoPhillips@Live.com      =
====================================